import 'package:flutter/material.dart';
import 'package:carousel_pro/carousel_pro.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import './detailPizza.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'PizzaFood',
      home: HomePage(),
    ));

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    Widget image_slider_carousel = Container(
      height: 200,
      child: Carousel(
        boxFit: BoxFit.fill,
        images: [
          AssetImage('http://ptdikp.com/gambar/img/img1.jpg'),
          AssetImage('http://ptdikp.com/gambar/img/img2.jpg'),
          AssetImage('http://ptdikp.com/gambar/img/img3.png'),
          AssetImage('http://ptdikp.com/gambar/img/pizza3.png'),
        ],
        autoplay: true,
        indicatorBgPadding: 1.0,
        //dotBgColor: Colors.greenAccent,
        //dotColor: Colors.red,
        dotSize: 3.0,
      ),
    );
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0.0,
        leading: Icon(Icons.arrow_back_ios),
        backgroundColor: Colors.red,
        title: Text('PizzaFood'),
        actions: <Widget>[
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.menu),
          ),
        ],
      ),
      body: ListView(
        children: <Widget>[
          image_slider_carousel,
          GreyArea,
          MainMenuList,
          GreyArea,
          Container(
            height: 100.0,
            child: ListView(
              padding: EdgeInsets.fromLTRB(0, 5, 2, 5),
              scrollDirection: Axis.horizontal,
              children: <Widget>[
                CircleAvatar(
                  radius: 50.0,
                  backgroundImage:
                      AssetImage('http://ptdikp.com/gambar/img/pizza3.png'),
                ),
                CircleAvatar(
                  radius: 50.0,
                  backgroundImage:
                      AssetImage('http://ptdikp.com/gambar/img/img1.jpg'),
                ),
                CircleAvatar(
                  radius: 50.0,
                  backgroundImage:
                      AssetImage('http://ptdikp.com/gambar/img/img3.png'),
                ),
                CircleAvatar(
                  radius: 50.0,
                  backgroundImage:
                      AssetImage('http://ptdikp.com/gambar/img/img2.jpg'),
                ),
                CircleAvatar(
                  radius: 50.0,
                  backgroundImage: AssetImage('iconImg/ph.jpg'),
                ),
                CircleAvatar(
                  radius: 50.0,
                  backgroundImage: AssetImage('iconImg/pc.jpg'),
                ),
              ],
            ),
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img1.jpg",
            judul: "Pizza Masters Rank",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img2.jpg",
            judul: "Pizza Pineapple",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img3.jpg",
            judul: "Pizza Ham",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img4.jpg",
            judul: "Pizza Peppers",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img5.jpg",
            judul: "Pizza Mushrooms",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img6.jpg",
            judul: "Pizza Spinach",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img7.jpg",
            judul: "Pizza Onions",
          ),
          new ListPizza(
            gambar: "http://ptdikp.com/gambar/ilmages/img8.jpg",
            judul: "Pizza Olives",
          ),
        ],
      ),
      bottomNavigationBar: CurvedNavigationBar(
        buttonBackgroundColor: Colors.white,
        backgroundColor: Colors.red,
        animationDuration: Duration(seconds: 1),
        animationCurve: Curves.bounceOut,
        items: <Widget>[
          Icon(
            Icons.home,
            color: Colors.red,
          ),
          Icon(
            Icons.shopping_cart,
            color: Colors.red,
          ),
          Icon(
            Icons.restaurant_menu,
            color: Colors.red,
          ),
          Icon(
            Icons.settings,
            color: Colors.red,
          ),
          Icon(
            Icons.favorite,
            color: Colors.red,
          ),
        ],
      ),
    );
  }
}

class ListPizza extends StatelessWidget {
  ListPizza({this.gambar, this.judul});

  final String gambar;
  final String judul;

  @override
  Widget build(BuildContext context) {
    return new Container(
      padding: new EdgeInsets.all(5.0),
      child: new Center(
        child: new Row(
          children: <Widget>[
            new Image(
              image: new NetworkImage(gambar),
              width: 120.0,
            ),
            new Container(
              padding: new EdgeInsets.all(5.0),
              child: new Center(
                child: new Column(
                  children: <Widget>[
                    new Text(
                      judul,
                      style: new TextStyle(fontSize: 18.0),
                    ),
                    RaisedButton(
                      child: Text(
                        "Go To Detail",
                        style: new TextStyle(fontSize: 13.0),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => detailPizza(),
                            ));
                      },
                    ),
                    //new Text("Klik Untuk Meihat Keterangan Pizza", style: new TextStyle(fontSize: 13.0, color: Colors.grey),)
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

//Widget PizzaCarousel = Container(...);

Widget GreyArea = Container(
  height: 6.0,
  color: Colors.grey[200],
);

var menuItems = [
  {'image': 'iconImg/ph.jpg', 'text': 'PizzaHot'},
  {'image': 'iconImg/pc.jpg', 'text': 'PizzaCool'},
  {'image': 'iconImg/dp.jpg', 'text': 'DoublePizza'},
  {'image': 'iconImg/mp.jpg', 'text': 'MediumPizza'},
  {'image': 'iconImg/kids.jpg', 'text': 'KidsPizza'},
  {'image': 'iconImg/dis.jpg', 'text': 'Promo'},
  {'image': 'iconImg/del.jpg', 'text': 'Delivery'},
  {'image': 'iconImg/help.jpg', 'text': 'Help'},
];
var MainMenuList = Container(
  height: 150.0,
  child: GridView.count(
      padding: EdgeInsets.fromLTRB(17, 10, 17, 10),
      crossAxisCount: 4,
      children: List.generate(menuItems.length, (index) {
        return Column(
          children: <Widget>[
            Container(
              height: 45.0,
              width: 45.0,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(0.0)),
                  border: Border.all(color: Colors.grey[50])),
              child: Center(
                child: Image.asset(menuItems[index]["image"]),
              ),
            ),
            Expanded(
              child: Text(
                menuItems[index]["text"],
                style: TextStyle(fontSize: 10.0),
              ),
            ),
          ],
        );
      })),
);

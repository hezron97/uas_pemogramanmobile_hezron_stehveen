import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

void main() => runApp(MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DetailPizza',
      home: detailPizza(),
    ));

class detailPizza extends StatefulWidget {
  @override
  _detailPizzaState createState() => _detailPizzaState();
}

class _detailPizzaState extends State<detailPizza> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        elevation: 0.0,
        leading: Icon(Icons.arrow_back_ios),
        backgroundColor: Colors.red,
        title: Text('DetailPizza'),
        actions: <Widget>[
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.menu),
          ),
        ],
      ),
      body: ListView(
        padding: EdgeInsets.fromLTRB(10, 18, 10, 18),
        children: <Widget>[
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img1.jpg",
          ),
          new Text(
            "Pizza Masters Rank",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Ham ini terbuat dari berbagai campuran bahan dengan menggunakan beberapa bahan alami seperti daun pandan, jahe, bumbu xiaoshi, dan metega. dari bahan tersebut diolah menjadi satu olahanan dan menghasilkan pizza yang begitu sehat untuk dikonsumsi.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 25-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img2.jpg",
          ),
          new Text(
            "Pizza Pineapple",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Pineapple ini terbuat dari berbagai campuran bahan.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img3.jpg",
          ),
          new Text(
            "Pizza Ham",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Ham ini sangat lezat dimakan dan cocok untuk orang tua yang berurumur karena memang cocok.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img4.jpg",
          ),
          new Text(
            "Pizza Peppers",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Peppers ini sangat manis rasanya dan gurih.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img5.jpg",
          ),
          new Text(
            "Pizza Mushrooms",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Mushrooms ini sangat lezat dimakan karena rasanya beda dengan yang lain.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img6.jpg",
          ),
          new Text(
            "Pizza Spinach",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Spinach ini sangat lezat dimakan karena rasanya pedah ada asin-asinnya.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img7.jpg",
          ),
          new Text(
            "Pizza Onions",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Onions ini sangat risenable untuk dibeli karna harganya sangat terjangkau.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
          new Image.network(
            "http://ptdikp.com/gambar/ilmages/img8.jpg",
          ),
          new Text(
            "Pizza Olives",
            style: new TextStyle(fontSize: 23.0, color: Colors.black),
          ),
          new Text(
            "Pizza Olives ini sangat layak dimakan untuk anak kecil karena tidak begituh pedas.",
            style: new TextStyle(fontSize: 15.0, color: Colors.grey),
          ),
          new Text("Tanggal : 18-12-2020",
              style: TextStyle(color: Colors.black)),
          new Icon(Icons.star, color: Colors.yellow[300]),
        ],
      ),
      bottomNavigationBar: CurvedNavigationBar(
        buttonBackgroundColor: Colors.white,
        backgroundColor: Colors.red,
        animationDuration: Duration(seconds: 1),
        animationCurve: Curves.bounceOut,
        items: <Widget>[
          Icon(
            Icons.home,
            color: Colors.red,
          ),
          Icon(
            Icons.shopping_cart,
            color: Colors.red,
          ),
          Icon(
            Icons.restaurant_menu,
            color: Colors.red,
          ),
          Icon(
            Icons.settings,
            color: Colors.red,
          ),
          Icon(
            Icons.favorite,
            color: Colors.red,
          ),
        ],
      ),
    );
  }
}

package com.example.PizzaFood

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
